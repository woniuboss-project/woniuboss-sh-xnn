#!/usr/bin/env python
# -*- coding: utf-8 -*-
#@Author:吴米珠
from find_image.Imageauto import ImageAuto
from appium import webdriver
import time,os

class TestAndorid:
    def __init__(self):
        #定义apk所在的路径
        # app_path = os.path.join(os.getcwdb(),"")
        self.desired_caps = {
            "platformName":"Android",
            "platformVersion":"4.4.4",
            "deviceName":"appium",
            "udid":"826ad637",
            "appPackage":"com.miui.calculator",
            "appActivity":".cal.CalculatorActivity",
            "unicodeKeyboard":"true", #允许键盘输入中文
            # "app":app_path #自动安装指定路径下的应用程序
        }
        self.url = "http://127.0.0.1:4723/wd/hub"

    def test(self):
        driver = webdriver.Remote(self.url,self.desired_caps)
        driver.implicitly_wait(10) #如果找不到,在20分钟内找不到报错.只有selenium有显示等待,appium是没有显示等待了
        time.sleep(2)
        #注意:find_element_by_android_uiautomator方法使用时引号必须外单内双，内双的字符串是会在java代码由android系统来执行
        driver.find_element_by_android_uiautomator('text("同意")').click()
        # driver.find_element_by_id("button1").click()
        #实现滚动的函数,三个参数,从哪里滚动到哪里,速度默认值600毫秒
        #driver.scroll(第一个元素定位,第二元素定位，1000)
        time.sleep(1)
        driver.find_element_by_id("com.miui.calculator:id/btn_9_s").click()
        # driver.find_element_by_id("com.miui.calculator:id/btn_plus_s").click()
        driver.find_element_by_accessibility_id("加").click() #识别content_desc的id
        driver.find_element_by_id("com.miui.calculator:id/btn_2_s").click()
        driver.find_element_by_accessibility_id("减").click()




        time.sleep(1)
        driver.quit()



if __name__ == '__main__':
    t = TestAndorid()
    t.test()
